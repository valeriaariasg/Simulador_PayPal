Una empresa financiera muy famosa te ha contratado para que desarrolles su nueva aplicación. Esta aplicación emula cómo funciona Zelle pero con nuevas funcionalidades que permiten hacer la experiencia de usuario mucho mejor. Para el desarrollo de esta aplicación se necesitarán las siguientes secciones:

1. Sección de Gestión de Usuarios
2. Sección de Pagos
3. Sección de Split
4. Sección de Estadísticas

Información importante en: observaciones

Sección 1: Gestión de Usuarios

En esta sección se explica el manejo de usuarios en la plataforma; existen dos tipos de usuarios: tipo empresa y tipo persona. Los usuarios en saman_pay cuando ingresen van a poder crearse una cuenta en la plataforma. Para crear una cuenta en la aplicación, la persona deberá tener una cuenta creada en algún banco afiliado, para ello el sistema se deberá conectar al Banking Network API que provee la información de los usuarios. El sistema deberá realizar el siguiente procedimiento en esta sección:

● Solicitar si se quiere crear una cuenta o iniciar sesión

● Si la persona desea crear una cuenta entonces el sistema le deberá pedir al banco donde posee cuenta (esta información debe ser extraída del API al momento de iniciar la APP) ○ Luego de seleccionar el banco la persona deberá ingresar su código personal del banco (informacion que esta en el API), luego si el código existe, el sistema deberá responder con su información, si es usuario tipo persona,
debeara mostrar: nombre completo, fecha de nacimiento, sexo y balance; si es empresa: nombre y balance; si no existe deberá responder con un mensaje de “codigo incorrecto” ○ Luego de que la persona valide sus datos, deberá afiliar un correo electrónico a su cuenta de saman_pay, para que esta pueda enviar y recibir dinero con ese correo electrónico y crear una contraseña para su cuenta.

● Si la persona ya tiene una cuenta creada en la plataforma, deberá iniciar sesión, para esto simplemente debe ingresar su correo electrónico y su contraseña de saman_pay para ingresar a su perfil.

● Luego la persona podrá ver su perfil con su correo electrónico, balance y información restante del banco también tendrá un menú para: cambiar el correo electrónico,
enviar dinero, solicitar dinero (solo usuarios tipo empresas), ver solicitudes de pago, ver directorio de contactos y cerrar sesión. El resto de estas vistas se explica en las siguientes secciones.

Sección 2: Gestión de Pagos

En esta sección se ahonda más en cómo el usuario debe realizar pagos, como se maneja el directorio y funcionalidades extras de los usuarios tipo empresa.

● Cuando un usuario desea hacer algún pago (transferencia) debe poder ingresar correo electrónico de la persona que quiere hacer la transferencia, el monto y una descripción. Se debe validar que el usuario destinatario existe en la base de datos de saman_pay, que el monto no exceda el balance del usuario emisor, y que la descripción (motivo de pago) no exceda 20 caracteres.

● saman_pay cobrará una comisión del 10% a los usuarios tipo empresa, y de 5% a los usuarios tipo persona. A menos que el monto sea un número capicúa y de ser así saman_pay quiere regalarle el pago sin tener una comisión.

● Si la transacción es aprobada debe salir una pantalla resumen con la transacción realizada, donde incluya la hora y fecha de la transacción con un código de 8 caracteres random que identifique esa transacción. Monto transferido con el detalle de la comisión. Esto se debe guardar en un historial de transacciones.

● Debe existir una vista para que el usuario pueda ver el historial de sus transacciones con toda la información de esa transacción: correo del destinatario, correo del emisor,fecha y hora de la transacción, código de la transacción,monto y descripción.

● Un usuario tipo empresa puede enviar una solicitud a un usuario para que le realice un pago, este debe incluir: correo del usuario a solicitar dinero, descripción y monto.
El usuario receptor debe poder ver en una vista “solicitudes de pago” en donde pueda aceptar la solicitud (creando una transacción automáticamente) o negar. El
usuario tipo empresa puede también ver un historial de solicitudes y de su estatus (aprobada o rechazada)

● Debe existir una vista directorio, en donde aparezca la lista de usuarios el cual se le han hecho pagos.

Sección 3: Split

Esta es una de las funcionalidades más atractivas de esta aplicación, ya que permitirá distribuir pagos de una compra que tenga diferentes gastos de manera equitativa. La mejor
manera de explicar esta funcionalidad es con un ejemplo:
Supongamos que Miguel quiere hacer una parrillada, invita a 4 amigos: Alesandra, Stefania, Gabriel y Omar. Se distribuyeron la compra de las cosas para que cada quien pueda aportar, pero decidieron que quieren tener gatos equitativos. Los gatos fueron de la siguiente manera.

● Miguel compró la carne y gasto $30

● Omar compro las bebidas y gasto $20

● Los platos, vasos y servilletas lo consigo Stefania por $12

● Alessandra llevará los ingredientes para hacer la ensalada y gasto $10

● Gabriel puso la casa y no compro nada.

En este ejemplo supongamos que Gabriel tiene saman_pay y decide usar la funcionalidad de split, él deberá ingresar lo antes dicho: nombre de sus amigos (no tienen que estar
registrados ni relacionados ya en el sistema es simplemente texto), y monto que gastó cada uno. Luego el sistema debe producir el siguiente output: La cuenta total es de $72, para hacer un pago equitativo y cada quien gaste $14.4 se deben hacer las siguientes transacciones:

● Alessandra debe pagar $4.40 a Miguel
● Gabriel debe pagar $11.20 a Miguel
● Gabriel debe pagar $3.20 a Omar
● Stefania debe pagar $2.40 a Omar

De esta manera cada uno terminó gastando $14.4 y la parrilla sale en un gasto equitativo. Debes desarrollar un algoritmo que emule esta funcionalidad en la aplicación de
saman_pay. Esto debe quedar guardado en un archivo de texto de tal manera de luego poder acceder y ver la información del split. Para eso se deberá guardar con algún título.

Sección 4: Estadísticas

saman_pay quiere tener unas estadísticas internas de como va comportándose su plataforma:

● Monto total recaudado por comisiones

● Monto total recaudado por tipo de usuario

● Cantidad de transferencias que fueron exoneradas de comisión por el hecho de ser un monto con números capicúa.

● Una lista con los usuarios con mas dinero en la plataforma, para esto deberás implementar algún algoritmo de ordenamiento dado en clases y especificar cuál se está usando.

● Cantidad de usuarios por tipo.

● Cantidad de splits realizados en la plataforma.

Observaciones:

● Link al Banking Network API: https://a.nacapi.com/saman_pay

● Se pueden usar librerías para generar los códigos random y obtener la fecha y hora.

● Se deben usar los conceptos de programación orientado a objetos

● Antes de realizar el código, es imperante que realicen un diagrama de clases y que la implementación de su proyecto sea uno a uno con el diagrama

● Se evaluará que el código este comentado (docstring)

● Se evaluará que el sistema contenga validaciones

● Se deberán guardar datos en un archivo TXT para preservar los datos en cada ejecución.

● El proyecto deberá ser entregado en Github Classroom a más tardar el 5 de Julio a las 11:59PM