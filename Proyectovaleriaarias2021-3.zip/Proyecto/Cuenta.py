class Cuenta(): #clase de la seccion 1, el registro

  def registro_usuarios(self,nombre,genero,nacimiento,balance): 
    self.nombre = nombre
    self.genero = genero
    self.nacimiento = nacimiento
    self.balance = balance

  # muestra la informacion al usuario

  def mostrar_informacion_usuario(self):
    print(f'\nInformación del usuario\n\nNombre: {self.nombre}\nGenero: {self.genero}\nFecha de nacimiento: {self.nacimiento}\nBalance: {self.balance}')

  # muestra la informacion al usuario

  def registro_compañias(self,nombre,balance):
    self.nombre_compañia = nombre
    self.balance_compañia = balance

  # muestra la informacion al usuario

  def mostrar_informacion_compañia(self):
    print(f'\nInformacion de la compañía:\n\nNombre: {self.nombre_compañia}\nBalance: {self.balance_compañia}')

  # muestra la informacion al usuario

  def mostrar_menu(self):

    print('\n<<MENU>>\n\n1.Transferencias\n2.Solicitar Dinero\n3.Directorio de contactos\n4.Solicitudes de pago\n5.Cambiar correo electrónico\n6.Split\n7.Cerrar sesión\n')