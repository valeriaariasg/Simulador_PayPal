def split(correo_usuario): # funcion de split
  
  amigos = [] # listas necesarias para el desarrollo del programa
  montos = []
  # solicitando informacion del usuario y las validaciones
  personas = input('\nCuantos amigos son?: ')

  while not personas.isnumeric() or int(personas) < 1 :   
    personas = input('\nCuantos amigos son?: ')
  # solicitando informacion del usuario y las validaciones
  x=0
  while x < int(personas): # Nombres de colaboradores
    amigo = input(f'\nIngresar nombre {x+1}: ')
    while not amigo.isalpha():
      amigo = input(f'\nIngresar nombre {x+1}: ')
    amigos.append(amigo)
    x+=1

  for j in range(len(amigos)): # Asignacion de Gastos referidos a cada contribuyente
    costos = input(f'\nIngresar gastos de {amigos[j]}: ')
    while not costos.isnumeric() or int(costos) < 1 :
      costos = input(f'\nIngresar gastos de {amigos[j]}: ')
    costos = float(costos)
    montos.append(costos)
  # ejecutando calculos
  nro_amigos = int(personas)
  cuenta_total = sum(montos)

  pagar_total = float(cuenta_total) / float(nro_amigos) # Debencias totales
  # imprimiendo la info en archivo txt
  funcion_split = open(f'split de {correo_usuario}.txt', 'a')
  y=0
  funcion_split.write(f'\n<<<<SPLIT RESPUESTA>>>')
  for j in range(int(personas)): # Guarda factura generada
    funcion_split.write(f'\n\nUsuario {y+1}: {amigos[j]} >>> Gasto: {montos[j]}')
    y+=1
  funcion_split.write(f'\n\nLa cuenta total >>>> {cuenta_total}\n\nPago por persona: {pagar_total}') # Factura 
  funcion_split.close()

  funcion_split = open(f'split de {correo_usuario}.txt', 'r')
  # se imprime la info del archivo al usuario
  return print(funcion_split.read())
