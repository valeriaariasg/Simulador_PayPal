pregunta = input('\n\nDesea hacer las comprar algo del catalogo de la tienda?\n1. Si\n2. No\nIngrese el indice correspondiente: ')
      while not pregunta.isnumeric() or not int(pregunta) >0 or not int(pregunta)< 3:
        pregunta = input('\n\nIngreso invalido\n\nDesea hacer las comprar algo del catalogo de la tienda?\n1. Si\n2. No\nIngrese el indice correspondiente: ')
      if int(pregunta) == 1:
          clientes.alfabetico()
          clientes.carrito()
      else: 
        menu = True

pregunta = input('\n\nDesea hacer las comprar algo del catalogo de la tienda?\n1. Si\n2. No\nIngrese el indice correspondiente: ')
      while not pregunta.isnumeric() or not int(pregunta) >0 or not int(pregunta)< 3:
        pregunta = input('\n\nIngreso invalido\n\nDesea hacer las comprar algo del catalogo de la tienda?\n1. Si\n2. No\nIngrese el indice correspondiente: ')

        if int(pregunta) == 1:
          Clientes.por_fecha()
          Clientes.carrito()
        else:
          menu = True

pregunta = input('\n\nDesea hacer las comprar algo del catalogo de la tienda?\n1. Si\n2. No\nIngrese el indice correspondiente: ')
      while not pregunta.isnumeric() or not int(pregunta) >0 or not int(pregunta)< 3:
        pregunta = input('\n\nIngreso invalido\n\nDesea hacer las comprar algo del catalogo de la tienda?\n1. Si\n2. No\nIngrese el indice correspondiente: ')

        if int(pregunta) == 1:
          Clientes.por_fecha()
          Clientes.carrito()
        else:
          menu = True

pregunta = input('\n\nDesea hacer las comprar algo del catalogo de la tienda?\n1. Si\n2. No\nIngrese el indice correspondiente: ')
      while not pregunta.isnumeric() or not int(pregunta) >0 or not int(pregunta)< 3:
        pregunta = input('\n\nIngreso invalido\n\nDesea hacer las comprar algo del catalogo de la tienda?\n1. Si\n2. No\nIngrese el indice correspondiente: ')

        if int(pregunta) == 1:
          Clientes.por_fecha()
          Clientes.carrito()
        else:
          menu = True