class Transacciones: # clase de transacciones de la seccion 2

  # metodos para el desarrollo del programa

  def informacion_transaccion(self,fecha,hora,codigo,monto,porcentaje):
    self.fecha = fecha
    self.hora = hora
    self.codigo = codigo
    self.monto = monto
    self.porcentaje = porcentaje

  # muestra la informacion al usuario

  def mostrar_transaccion(self):
    print(f'\nTRANSACCION EXITOSA\n\nFecha: {self.fecha}\nHora: {self.hora}\nCodigo de transaccion: {self.codigo}\nMonto:{float(self.monto)} >>> Comision: {self.porcentaje} ')

  # muestra la informacion al usuario

  def historial_transacciones(self,nombre_emisor,emisor,destinatario,fecha,hora,codigo,monto,descripcion,numero):
    self.nombre = nombre_emisor
    self.emisor = emisor
    self.destinatario = destinatario
    self.fecha = fecha
    self.hora = hora
    self.codigo = codigo
    self.monto = monto
    self.descripcion = descripcion
    self.numero = numero

  # muestra la informacion al usuario

  def mostrar_historial(self):
    print('\nHistorial de Transacciones\n')
    print(f'\n{self.numero + 1}.Transaccion de {self.nombre}\n\nCorreo del emisor: {self.emisor}\nCorreo del destinatario: {self.destinatario}\nFecha de la transaccion: {self.fecha}\nHora de la transaccion: {self.hora}\nCodigo de la transaccion: {self.codigo}\nMonto transferido:{self.monto}\nDescripcion de la transferencia: {self.descripcion}')
