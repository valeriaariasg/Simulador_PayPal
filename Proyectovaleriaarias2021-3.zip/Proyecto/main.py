# Librerias y funciones
import requests                                         # Libreria para invocar a la API
import Funciones                                        # Importacion de funciones especiales del archivo Funciones.py
from Cuenta import Cuenta                               # Importacion de la Clase Cuenta
from Transacciones import Transacciones                 # Importacion de la Clase Transacciones
import Seccion3 
#Importacion de la funcion de split
import Seccion4
#importacion de las estadisticas del programa

# ============================
#           Codigo:
# ============================

def main(): # Funcion principal

  url = 'https://a.nacapi.com/saman_pay' # LLamado de la API
  response = requests.get(url) # Obtencion de la API

  if response.status_code == 200: 
    response_json = response.json()  
    contenidos = response_json #convercion de la API a un diccionario
  contenido = contenidos[0] 

# Seccion 1: Gestión de Usuarios

  #variables necesarias para validacion del programa
  cuenta_vieja = False
  registro_completo = False

  solicitar_informacion1 = input('BIENVENIDO A SAMAN PAY\n\n1. Crear cuenta\n2.Iniciar sesion\n>>> ') # Llamado input principal
  
  while not solicitar_informacion1.isnumeric() or int(solicitar_informacion1) < 1 or int(solicitar_informacion1) > 2: # Llamado del input principal
    solicitar_informacion1 = input('1. Crear cuenta\n2.Iniciar sesion\n>>> ')

  if solicitar_informacion1 == '1': # Primera opcion (Crear una cuenta)
    print(f'\n')
    bancos_afiliados = ['bank of Saman', 'Grupo Banco', 'Avila Bank'] # Posibles bancos
    x = 0
    for j in range(len(bancos_afiliados)):  #Posibles bancos a elegir
      banco = bancos_afiliados[j]
      print(f'{x+1}. {banco.title()}') 
      x += 1
    
    eleccion_banco = input(f'\nElija el indice correspondiente a su banco: ') # pedirle datos: banco
      
    while not eleccion_banco.isnumeric() or int(eleccion_banco) < 1 or int(eleccion_banco) > 3: #validacion 
      x = 0
      for j in range(len(bancos_afiliados)):
        banco = bancos_afiliados[j]
        print(f'{x+1}.{banco}')
        x+=1
      eleccion_banco = input(f'\nElija el indice correspondiente a su banco: ') # Indice de banco

    codigo_banco = input('\nIngrese su codigo personal (4 digitos): ') # Ingreso del PIN 4 digitos de seguridad almacenado en la BD
    
    while not codigo_banco.isnumeric() or len(codigo_banco) > 4:
      codigo_banco = input('\nIngrese su codigo personal (4 digitos): ') # validacion
    
    for j in range(len(contenido)): #Sustraer datos de la BD
      nombre_banco = bancos_afiliados[int(eleccion_banco)-1]
      codigos = contenido[nombre_banco][j]['code']
      nombre = contenido[nombre_banco][j]['full_name']
      balance = contenido[nombre_banco][j]['balance'][1:]

      if contenido[nombre_banco][j]['company'] == False: #verificar si es persona o compania / Sustraer datos de la BD
        persona = True
        genero = contenido[nombre_banco][j]['gender'] 
        nacimiento = contenido[nombre_banco][j]['birthdate']
        #estadisticas tipo de usuario
        estadisticas_personas = open('tipo persona.txt','a')
        estadisticas_personas.write(f'\n1,')
        estadisticas_personas.close()

      else: #verificar si es persona o compania
        persona = False
        #estadisticas tipo usuario
        estadisticas_companias = open('tipo compania.txt', 'a')
        estadisticas_companias.write(f'\n1,')
        estadisticas_companias.close()

      if codigos == int(codigo_banco): #verificar que codigo almacenado en BD es el mismo que el usuario ingreso
        continuar_seccion2 = True
        if persona == True:
          cuenta = Cuenta() #mostrar los datos del usuario (persona) al registrarse
          cuenta.registro_usuarios(nombre,genero,nacimiento,float(balance))
          cuenta.mostrar_informacion_usuario()

        if persona == False:
          cuenta = Cuenta() #mostrar los datos del usuario (compania) al registrarse
          cuenta.registro_compañias(nombre,float(balance))
          cuenta.mostrar_informacion_compañia()
        
        verificacion_correo = False #variable necesaria para validacion del correo

        while verificacion_correo == False:
          correo_usuario = input('\nRegistre el correo de su nueva cuenta (username@domain.estension): ').lower() #Nuevo usuario
          
          if Funciones.email(correo_usuario): #validar el correo
            verificacion_correo = True

            contrasena = input('\nIngresar contraseña (4 dígitos): ') # Ingreso del PIN 4 digitos de seguridad
            while not contrasena.isnumeric() or len(contrasena) > 4:
              contrasena = input('\nIngresar contraseña (4 dígitos): ') # Ingreso del PIN 4 digitos de seguridad (again)

            #registro de nombres
            registro_nombre = open('nombres.txt', 'a')
            registro_nombre.write(f'\n{nombre},')
            registro_nombre.close()
            #registro de correo
            registro_correo = open('correos electronicos.txt','a')
            registro_correo.write(f'\n{correo_usuario},')
            registro_correo.close()
            #registro contrasena
            registro_contrasena = open('contrasenas.txt','a')
            registro_contrasena.write(f'\n{contrasena},')
            registro_contrasena.close()
            #registro balance
            registro_balance = open('balances.txt','a')
            registro_balance.write(f'\n{balance},')
            registro_balance.close()
            #registo del banco
            registro_banco = open('bancos.txt','a')
            registro_banco.write(f'\n{nombre_banco},')
            registro_banco.close()
            
            #otorgar una variable al contenido de los archivos.txt
            lista_nombres = Funciones.crear_lista('nombres.txt')
            lista_correos = Funciones.crear_lista('correos electronicos.txt')
            lista_contrasenas = Funciones.crear_lista('contrasenas.txt')
            lista_balances = Funciones.crear_lista('balances.txt')
            lista_bancos = Funciones.crear_lista('bancos.txt')
            #eliminar los datos repetidos innecesarios
            if lista_correos.count(correo_usuario) > 1:
              lista_nombres = set(lista_nombres) 
              lista_nombres = list(lista_nombres)
              lista_correos = set(lista_correos) 
              lista_correos = list(lista_correos)
              lista_contrasenas = set(lista_contrasenas) 
              lista_contrasenas = list(lista_contrasenas)
              lista_balances = set(lista_balances) 
              lista_balances = list(lista_balances)
              lista_bancos = set(lista_bancos) 
              lista_bancos = list(lista_bancos)
              print(f'\nYa tienes una cuenta') #ya esta registrado
            else:
              print(f'\nRegistrado exitosamente') # Registro logrado

              continuar_seccion2 = True #variable que necesitaremos mas adelante para el programa

          else:
            print('\nCorreo inválido') # Rechaza correo
            verificacion_correo = False

  if solicitar_informacion1 == '2': # Segunda opcion del input principal (Inicio de sesion)

    #otorgar una variable al contenido de los archivos.txt
    lista_nombres = Funciones.crear_lista('nombres.txt')
    lista_correos = Funciones.crear_lista('correos electronicos.txt')
    lista_contrasenas = Funciones.crear_lista('contrasenas.txt')
    lista_balances = Funciones.crear_lista('balances.txt')
    lista_bancos = Funciones.crear_lista('bancos.txt')

    verificacion_correo = False   #variables necesarias para el desarrollo del programa
    verificacion_contraseña = False

    while verificacion_correo == False: # Ciclo de verificacion de correo
      correo_usuario = input('\nIngrese su correo (username@domain.estension): ').lower()
      if len('correos electronicos') == 0: #no hay nadie registrado en BD de Saman Pay
        print('No existe este correo') 
        verificacion_correo = True
      else:
        for j in range(len(lista_correos)): #ciclo para sustraer y verificar datos de la BD

          if correo_usuario == lista_correos[j]: # Correo verificado exitosamente
            indice = lista_correos.index(correo_usuario)
            contraseña_valida = lista_contrasenas[indice]
            nombre_usuario = lista_nombres[indice]
            banco_afiliado = lista_bancos[indice]
            balance_actual = lista_balances[indice]
            verificacion_correo = True 
    
    while verificacion_contraseña == False: # Verificacion de la contraseña
      contraseña = input('\nIngresar contraseña (4 dígitos): ')
    
      if contraseña == contraseña_valida: # Validacion de contraseña
        verificacion_contraseña = True
        registro_completo = True
      else:
        verificacion_contraseña = False

    for j in range(len(contenido)): #sustrayendo datos de la BD
      
      balance = contenido[banco_afiliado][j]['balance']
      nombre = contenido[banco_afiliado][j]['full_name']

      if contenido[banco_afiliado][j]['company'] == False: #verificacion de tipo de usuario (persona/compania)/ sustrayendo datos de la BD
        persona = True
        genero = contenido[banco_afiliado][j]['gender']
        nacimiento = contenido[banco_afiliado][j]['birthdate']
      else:
        persona = False

      if nombre_usuario == nombre: #validar nombre de usuario en BD
        print(f'\nInformación:\n\nCorreo electrónico: {correo_usuario}\nBanco afiliado: {banco_afiliado}') #impresion de informacion del usuario
        if persona == True: #informacion del usuario (persona)
          cuenta = Cuenta()
          cuenta.registro_usuarios(nombre,genero,nacimiento,balance)
          cuenta.mostrar_informacion_usuario()
          cuenta.mostrar_menu()

        if persona == False: #informacion del usuario (compania)
          cuenta = Cuenta()
          cuenta.registro_compañias(nombre,balance)
          cuenta.mostrar_informacion_compañia()
          cuenta.mostrar_menu() #impresion del menu al usuario
  
  # Seccion 2 del programa
  continuar_seccion2 = True #variable necesaria para el desarrollo del programa
  while continuar_seccion2 == True and registro_completo == True and cuenta_vieja == False: #el programa continua si el usuario lo desea

    solicitar_informacion2 = input('\nQue desea hacer? Elija el indice: ')
    while not solicitar_informacion2.isnumeric() or int(solicitar_informacion2) < 1 or int(solicitar_informacion2) > 7:
      solicitar_informacion2 = input('\nQue desea hacer? Elegir indice: ')

    if solicitar_informacion2 == '1': #Programa para las transacciones
      
      print('\n1.Realizar transferencia\n2.Historial Transacciones') #mostrar opciones al usuario
      eleccion_transferencias = input('\nElegir un indice: ')

      while not eleccion_transferencias.isnumeric() or int(eleccion_transferencias) < 1 or int(eleccion_transferencias) > 3: #ciclo
        print('\n1.Realizar transferencia\n2.Historial Transacciones')
        eleccion_transferencias = input('\nElegir un indice: ')
      
      if eleccion_transferencias == '1': #programa para realizar transferencias
        correo_destinatario = input('Ingresar correo del destinatario: ').lower() #usuario que recibira la transaccion

        for j in range(len(lista_correos)): #verificar que se encuentre en BD Saman Pay
          if correo_destinatario == lista_correos[j]:
            monto = input('Ingresar monto: ') #monto a depositar
            
            while not monto.isnumeric() or float(monto) < 1.0: #ciclo del monto para su validacion
              monto = input('Ingresar monto: ')
            
            if float(monto) <= float(balance_actual): #evaluar monto con balance y sacar su comision

              if Funciones.numeros_capicua(monto) == True: #evaluar monto capicuo
                porcentaje_comision = '0%' #monto capicuo, 0% comision
                comision_balance = 0.0
                #estadisticas exoneraciones
                exoneradas = open('exoneradas.txt','a')
                exoneradas.write(f'\n1,')
                exoneradas.close()
              else:
                if persona == False: #usuario tipo empresa 10% comision
                  porcentaje_comision = '10%'
                  comision_balance = float(balance_actual) - ((0.10*float(balance_actual))/100.0)

                  #estadisticas comisiones
                  comisiones = open('comisiones.txt','a')
                  comisiones.write(f'\n{comision_balance},')
                  comisiones.close()
                  #estadisticas ganancias por compania
                  total_companias = open('companias.txt','a')
                  total_companias.write(f'\n{comision_balance},')
                  total_companias.close()

                if persona == True: #usuario tipo persona 5% comision
                  porcentaje_comision = '05%'
                  comision_balance = float(balance_actual) - ((0.5*float(balance_actual))/100.0) 
                  #estadisticas comisiones
                  comisiones = open('comisiones.txt','a')
                  comisiones.write(f'\n{comision_balance},')
                  comisiones.close()
                  #estadisticas ganancias por persona
                  total_personas = open('personas.txt','a')
                  total_personas.write(f'\n{comision_balance},')
                  total_personas.close()

            if correo_destinatario == lista_correos[j]: # calculando el balance para el usuario receptor y emisor
              indice = lista_correos.index(correo_destinatario)
              balance_anterior = lista_balances[indice]
              balance_recibido = float(balance_anterior) + float(monto)
              lista_balances[indice]= balance_recibido #actualizacion en la BD

              Funciones.retornar_valores(lista_balances, 'balances.txt') #actualizacion en los archivos

              indice = lista_correos.index(correo_usuario)
              balance_total = float(balance_actual) - float(monto)- comision_balance #calculando el cambio del balance para usuario emisor
              lista_balances[indice] = balance_total #actualizacion balance en la BD

              Funciones.retornar_valores(lista_balances, 'balances.txt')
                    
              descripcion_transferencia = input('Ingrese una descripcion (menos de 20 caracteres):\n>>>>> ') #descripcion de pago

              while len(descripcion_transferencia) > 21: #validacion de la descripcion
                descripcion_transferencia = input('Ingrese una descripcion (menos de 20 caracteres):\n>>>>> ')
              
              for j in range(len(lista_correos)):
                if correo_usuario == lista_correos[j]:
                  indice = lista_correos.index(correo_usuario)
                  nombre_emisor = lista_nombres[indice]

              hora_transferencia = Funciones.hora()
              fecha_transferencia = Funciones.fecha()
              codigo_transaccion = Funciones.codigo_random() #ejecutando la creacion del codigo random de transaccion
              transacciones = Transacciones() #llamando a la Clase Transacciones
              transacciones.informacion_transaccion(fecha_transferencia,hora_transferencia,codigo_transaccion, monto, porcentaje_comision) #agregando valor a los atributos de la clase
              transacciones.mostrar_transaccion() #imprimiendo la informacion de la transaccion

              #registro de las transacciones
              transaccion_nombre = open('usuarios transacciones.txt', 'a')
              transaccion_nombre.write(f'\n{nombre_emisor},')
              transaccion_nombre.close()
              #registro de correo del emisor
              emisor_correo = open('correos emisores.txt','a')
              emisor_correo.write(f'\n{correo_usuario},')
              emisor_correo.close()
              #registro de correo del receptor
              receptor_correo = open('correos receptores.txt','a')
              receptor_correo.write(f'\n{correo_destinatario},')
              receptor_correo.close()
              #registro de la fecha
              transaccion_fecha = open('fechas transacciones.txt', 'a')
              transaccion_fecha.write(f'\n{fecha_transferencia},')
              transaccion_fecha.close()
              #registro de hora
              transaccion_hora = open('horas transacciones.txt', 'a')
              transaccion_hora.write(f'\n{hora_transferencia},')
              transaccion_hora.close()
              #registro de codigo
              transaccion_codigo = open('codigos transacciones.txt', 'a')
              transaccion_codigo.write(f'\n{codigo_transaccion},')
              transaccion_codigo.close()
              #registro montos
              transaccion_monto = open('montos transacciones.txt', 'a')
              transaccion_monto.write(f'\n{float(monto)},')
              transaccion_monto.close()
              #registo de la descripcion
              transaccion_descripcion = open('descripciones transacciones.txt', 'a')
              transaccion_descripcion.write(f'\n{descripcion_transferencia},')
              transaccion_descripcion.close()

              contactos = []
              for j in range(len(lista_correos)):
                if correo_destinatario == lista_correos[j]:
                  indice = lista_correos.index(correo_destinatario)
                  nombre_receptor = lista_nombres[indice] #asignando usuarios
                  contactos.append(nombre_receptor) #agregando al usuario a la lista
                  set(contactos) #quitar a los repetidos
                  contactos = list(contactos) #convertir en lista para seguir manipulando
                  for i in range(len(contactos)): #impresion de cada contacto en la lista
                    contactos_usuario = open(f'contactos de {correo_usuario}.txt','a')
                    contactos_usuario.write(f'\n{contactos[i]},')
                    contactos_usuario.close()

                  #variables necesarias para el desarrollo del programa
                  culminado = True
                  continuar_seccion2 = False
                else:
                  #variables necesarias para el desarrollo del programa
                  culminado = True
                  continuar_seccion2 = False

      if eleccion_transferencias == '2': #ver el historial de las transacciones realizadas
        usuarios_transacciones = Funciones.crear_lista('usuarios transacciones.txt')
        correos_emisores = Funciones.crear_lista('correos emisores.txt')
        correos_receptores = Funciones.crear_lista('correos receptores.txt')
        fechas_transacciones = Funciones.crear_lista('fechas transacciones.txt')
        horas_transacciones = Funciones.crear_lista('horas transacciones.txt')
        codigo_transacciones = Funciones.crear_lista('codigos transacciones.txt')
        monto_transacciones = Funciones.crear_lista('montos transacciones.txt')
        descripciones_transacciones = Funciones.crear_lista('descripciones transacciones.txt')
        
        x=0
         #sustrayendo datos de la BD de Saman Pay

        indices = Funciones.buscar_indice(correos_emisores, correo_usuario)

        for j in range(len(indices)):
          y = indices[j]

          nombre_emisor = usuarios_transacciones[y]
          correo_emisor1 = correos_emisores[y]
          correo_destinatario = correos_receptores[y]
          fecha_transaccion = fechas_transacciones[y]
          hora_transaccion = horas_transacciones[y]
          codigo_transferencia = codigo_transacciones[y]
          monto_transaccion = monto_transacciones[y]
          descripcion_transaccion = descripciones_transacciones[y]

          transacciones = Transacciones() #llamando a la Clase Transacciones
          transacciones.historial_transacciones(nombre_emisor,correo_emisor1,correo_destinatario,fecha_transaccion,hora_transaccion,codigo_transferencia,monto_transaccion,descripcion_transaccion,x) #otorgando valores a los atributos
          transacciones.mostrar_historial() #impresion del historial
          x+=1
          culminado = True #variables necesarias para el desarrollo del programa
          continuar_seccion2 = False

    if solicitar_informacion2 == '2': #programa para solicitudes de pago
      if persona == False:
        eleccion_solicitudes = input('\n1.Solicitar pago\n2.Estatus de solicitudes\n>>>> ') #eleccion para el usuario
        
        while not eleccion_solicitudes.isnumeric() or int(eleccion_solicitudes) < 1 or int(eleccion_solicitudes) > 3:
          eleccion_solicitudes = input('\n1.Solicitar pago\n2.Estatus de solicitudes\n>>>> ') #validacion de eleccion
        
        if eleccion_solicitudes == '1': #realizar solicitud de pago
          correo_solicitud = input('Ingresar correo del destinatario: ').lower() #solicitando correo del destinatario

          for j in range(len(lista_correos)): #sustrayendo datos de la BD
            if correo_solicitud == lista_correos[j]:
              indice = lista_correos.index(correo_solicitud)
              nombre_contacto = lista_nombres[indice]
              monto_solicitud = input('Ingresar monto: ') #monto a solicitar
              
              while not monto_solicitud.isnumeric() or float(monto_solicitud) < 1.0: #validacion del monto
                monto_solicitud = input('Ingresar monto: ')

              descripcion_solicitud = input('Ingrese una descripcion (menos de 20 caracteres)\n>>>>> ') #descripcion de solicitud

              while len(descripcion_solicitud) > 21: #validacion de la descripcion
                descripcion_solicitud = input('Ingrese una descripcion (menos de 20 caracteres)\n>>>>> ')

              #registo del numero de solicitudes
              with open('posiciones.txt') as doc:
                contenido = doc.read()

                m = contenido.split(',')[0]   
              status_posicion = open('posiciones.txt', 'a')
              status_posicion.write(f'\n{len(m)+1},')
              status_posicion.close()
              #registro del contacto
              status_contacto = open('contacto solicitudes.txt','a')
              status_contacto.write(f'\n{nombre_contacto},')
              status_contacto.close()
              #registro del status
              estatus = open('estatuses.txt','a')
              estatus.write(f'\nen espera,')
              estatus.close()

              #registo del numero de solicitudes de pago
              with open('pagos.txt') as doc:
                contenido = doc.read()

                n = contenido.split(',')[0]
              pago_posicion = open('pagos.txt', 'a')
              pago_posicion.write(f'\n{len(n)+1},')
              pago_posicion.close()
              #registro del contacto que solicita el pago
              solicitador_contacto = open('solicitudes de contacto.txt','a')
              solicitador_contacto.write(f'\n{nombre_contacto},')
              solicitador_contacto.close()
              #registro del contacto que acepta o rechaza solicitud
              solicitado_contacto = open('solicitados.txt','a')
              solicitado_contacto.write(f'\n{nombre_usuario},')
              solicitado_contacto.close()
              #registro del monto solicitado
              solicitudes_monto = open('montos solicitudes.txt', 'a')
              solicitudes_monto.write(f'\n{monto_solicitud},')
              solicitudes_monto.close()
              #registro de la decision 
              decisiones = open('decisiones.txt', 'a')
              decisiones.write(f'\ndecision en espera,')
              decisiones.close()
              
              print('\nSolicitud enviada') #solicitud exitosa
              culminado = True #variables necesarias para el desarrollo del programa
              continuar_seccion2 = False
            else:
              culminado = True #variables necesarias para el desarrollo del programa
              continuar_seccion2 = False
        if eleccion_solicitudes == '2': #ver el historial de solicitudes y conocer su estatus
          status_posicion = Funciones.crear_lista('posiciones.txt')
          status_contacto = Funciones.crear_lista('contacto solicitudes.txt')
          estatus = Funciones.crear_lista('estatuses.txt')
          solicitado_contacto = Funciones.crear_lista('solicitados.txt')
          x=0
          if len(status_posicion) == 0:
            print('\nSin historial de solicitudes') #no hay solicitudes
          else:  
            #sustrayendo informacion de la BD
            for j in range(len(lista_correos)):
              if correo_usuario == lista_correos[j]:
                indice = lista_correos.index(correo_usuario)
                nombre = lista_nombres[indice]
            indices = Funciones.buscar_indice(solicitado_contacto, nombre)
            for j in range(len(indices)): 
              y = indices[j]
              nombre_solicitado = status_contacto[y]
              estatus_actual = estatus[y]
              print(f'\n{x+1}.{nombre_solicitado} >>> Estatus: {estatus_actual}') #Impresion del historial
              x+=1
              culminado = True
      else: #los usuarios personas no pueden acceder a solicitudes de pago
        culminado = True #variables necesarias para el desarrollo del programa
        continuar_seccion2 = False

    if solicitar_informacion2 == '3': #directorio de contactos
      lista_directorio = Funciones.crear_lista(f'contactos de {correo_usuario}.txt')
      
      if len(lista_directorio) == 0: #0 contactos almacenados
        print('\nNo hay contactos almacenados')
      else: #almacenar contactos y eliminar nombres repetidos
        x=0
        lista_directorio.pop(0)
        lista_directorio = set(lista_directorio)
        lista_directorio = list(lista_directorio)
        for j in range(len(lista_directorio)):
          print(f'\n{x+1}.{lista_directorio[j]}') #imprimir contactos del usuario
          x+=1
        culminado = True #variables necesarias para el desarrollo del programa
        continuar_seccion2 = False
    
    if solicitar_informacion2 == '4': #acceder a las solicitudes de pagos que le hacen al usuario

      pago_posicion = Funciones.crear_lista('pagos.txt')
      solicitador_contacto = Funciones.crear_lista('solicitudes de contacto.txt')
      solicitado_contacto = Funciones.crear_lista('solicitados.txt')
      solicitudes_monto = Funciones.crear_lista('montos solicitudes.txt')
      decisiones = Funciones.crear_lista('decisiones.txt')

      if len(pago_posicion) == 0:
        print('Sin solicitudes') #no hay solicitudes
      else:
        x=0
        for j in range(len(solicitador_contacto)):
          if nombre_usuario == solicitador_contacto[j]:
            indices = Funciones.buscar_indice(solicitador_contacto, nombre_usuario)
            
            for j in range(len(indices)):
              y = indices[j]
              nombre_solicitud = solicitado_contacto[y]
              monto_pagar = solicitudes_monto[y]
              decision_estatus = decisiones[y]

              print(f'\n{x+1}.{nombre_solicitud} >>> Monto: {monto_pagar} >>> {decision_estatus}') # Muestra de monto a pagar
              x+=1
              
            decision_paga = input('\nIndique el indice de la solicitud: ') #impresion de las solicitudes

            while not decision_paga.isnumeric() or int(decision_paga) < 1 or int(decision_paga) > len(pago_posicion):
              decision_paga = input('\nIndique el indice de la solicitud: ') #elegir que solicitud aceptar/rechazar
            cambio_estatus = input('\n1.Aceptar\n2.Rechazar\n>>> ') #opciones para aceptar/rechazar solicitud

            while not cambio_estatus.isnumeric() or int(cambio_estatus) < 1 or int(cambio_estatus) > 3:
              cambio_estatus = input('\n1.Aceptar\n2.Rechazar\n>>> ') #validacion de opcion
            for j in range(len(pago_posicion)):
              if decision_paga == pago_posicion[j]:
                indice = pago_posicion.index(decision_paga)
                status = decisiones[indice]
                if status == 'decision en espera':
                  pass
                else:
                  culminado = True

            if cambio_estatus == '1':#aceptar solicitudes
              status_posicion = Funciones.crear_lista('posiciones.txt')
              status_contacto = Funciones.crear_lista('contacto solicitudes.txt')
              estatus = Funciones.crear_lista('estatuses.txt')

              for j in range(len(status_contacto)): 
                if nombre_usuario == status_contacto[j] and decision_paga == status_posicion[j]: #comprobar datos
                  indice = status_posicion.index(decision_paga)
                  estatus[indice] = 'ACEPTADA' #cambiar el estatus de la solicitud 
                  Funciones.retornar_valores(estatus, 'estatuses.txt') #actualizacion en los archivos
                
                for j in range(len(lista_correos)): #cambiar el balance del usuario

                  if correo_usuario == lista_correos[j]:
                    indice = lista_correos.index(correo_usuario)
                    balance_activo = lista_balances[indice]

                    if float(monto_pagar) <= float(balance_actual): #evaluar monto con balance y sacar su comision

                      if Funciones.numeros_capicua(monto_pagar) == True: #evaluar monto capicuo
                        porcentaje_comision = '0%' #monto capicuo, 0% comision
                        comision_balance = 0.0
                        #estadisticas exoneraciones
                        exoneradas = open('exoneradas.txt','a')
                        exoneradas.write(f'\n1,')
                        exoneradas.close()

                        cambio_balance = float(balance_activo) - float(monto_pagar)
                        lista_balances[indice] = cambio_balance #actualizacion del balance
                        Funciones.retornar_valores(lista_balances, 'balances.txt')
                      else:
                        if persona == False: #usuario tipo empresa 10% comision
                          porcentaje_comision = '10%'
                          comision_balance = float(balance_actual) - ((0.10*float(balance_actual))/100.0)
                          #estadisticas comisiones
                          comisiones = open('comisiones.txt','a')
                          comisiones.write(f'\n{comision_balance},')
                          comisiones.close()
                          #estadisticas ganancias por persona
                          total_companias = open('companias.txt','a')
                          total_companias.write(f'\n{comision_balance},')
                          total_companias.close()
                          #cambio balance
                          cambio_balance = float(balance_activo) - float(monto_pagar) - comision_balance
                          lista_balances[indice] = cambio_balance #actualizacion del balance
                          Funciones.retornar_valores(lista_balances, 'balances.txt')

                        if persona == True: #usuario tipo persona 5% comision
                          porcentaje_comision = '05%'
                          comision_balance = float(balance_actual) - ((0.5*float(balance_actual))/100.0) 
                          #estadisticas comisiones
                          comisiones = open('comisiones.txt','a')
                          comisiones.write(f'\n{comision_balance},')
                          comisiones.close()
                          #estadisticas ganancias por persona
                          total_personas = open('personas.txt','a')
                          total_personas.write(f'\n{comision_balance},')
                          total_personas.close()

                          cambio_balance = float(balance_activo) - float(monto_pagar) - comision_balance
                          lista_balances[indice] = cambio_balance # actualizacion del balance
                          Funciones.retornar_valores(lista_balances, 'balances.txt')
                    else:
                      for j in range(len(status_contacto)): 
                        if nombre_usuario == status_contacto[j] and decision_paga == status_posicion[j]: # comprobar datos
                          indice = status_posicion.index(decision_paga)
                          estatus[indice] = 'MONTO INSUFICIENTE' # cambiar el estatus de la solicitud 
                          Funciones.retornar_valores(estatus, 'estatuses.txt') #actualizacion en los archivos

              for j in range(len(pago_posicion)): #cambiando estatus 
                if decision_paga == pago_posicion[j]:
                  indice = pago_posicion.index(decision_paga)
                  decisiones[indice] = 'ACEPTADA'
                
                  Funciones.retornar_valores(decisiones, 'decisiones.txt') # actualizacion en los archivos 
                
            if cambio_estatus == '2': # rechazar solicitudes

              status_posicion = Funciones.crear_lista('posiciones.txt')
              status_contacto = Funciones.crear_lista('contacto solicitudes.txt')
              estatus = Funciones.crear_lista('estatuses.txt')
              
              for j in range(len(pago_posicion)): #cambiando estatus

                if nombre_usuario == status_contacto[j] and decision_paga == status_posicion[j]: # comprobar datos
                  indice = status_posicion.index(decision_paga)
                  estatus[indice] = 'RECHAZADA' # cambiar el estatus de la solicitud 
                  Funciones.retornar_valores(status, 'estatuses.txt')
                  culminado = True

                if int(decision_paga) == pago_posicion[j]: #cambiando estatus
                  indice = pago_posicion.index(decision_paga)
                  decisiones[indice] = 'RECHAZADA'
                  Funciones.retornar_valores(decisiones, 'decisiones.txt')
                  culminado = True
            else:
              culminado = True

    if solicitar_informacion2 == '5': # cambio de correo 
      indice = lista_correos.index(correo_usuario)
      verificacion_correo = False
      while verificacion_correo == False: # validar el correo nuevo
        correo_nuevo = input('\nIngresar correo nuevo (username@domain.com): ').lower() # ingresar nuevo correo
        if Funciones.email(correo_nuevo): # validando correo con la funcion
          verificacion_correo = True 
          lista_correos[indice] = correo_nuevo # correo nuevo validado
          print(f'\nCambio de correo exitoso') # actualizacion del correo

          Funciones.retornar_valores(lista_correos, 'correos electronicos.txt')
          culminado = True
        else:
          print('Correo invalido') # el correo no es valido, debe ingresar otro
          culminado = True

    if solicitar_informacion2 == '6': #seccion 3, funcion split
      print('\nBienvenido a la funcion SPLIT') #registro de datos e impresion de resultados
      Seccion3.split(correo_usuario)
      culminado = True

      #estadisticas del numero de veces utilizada la funcion split
      estadisticas_splits = open('splits.txt','a')
      estadisticas_splits.write(f'\n1,')
      estadisticas_splits.close()
          
    if solicitar_informacion2 == '7': # cerrar sesion
      print('\nGracias por elegir Saman Pay') # despedida chill
      continuar_seccion2 = False # variables necesarias para detener ejecucion del programa
      culminado = False

    #asegurar que se repita el programapor decision del usuarios
    if culminado == True: # usuario puede elegir continuar o no en el programa, se repite despues de cada accion
      continuar = input('\nProceso culminado\n\n1.Continuar\n2.Terminar\n>>>') # mostrando opciones:
      
      while not continuar.isnumeric() or int(continuar) < 1 or int(continuar) > 3: # ciclo de validacion:
        continuar = input('\nProceso culminado\n\n1.Continuar\n2.Terminar')
      
      if continuar == '1': # continuar programa
        cuenta.mostrar_menu() # imprime menu principal nuevamente
        continuar_seccion2 = True # variables necesarias para el desarrollo del programa
        
      if continuar == '2': # terminar programa
        print('\nGracias por elegir Saman Pay') # despedida chill, detiene ejecucion programa
        continuar_seccion2 = False # variables necesarias para el desarrollo del programa
        Seccion4.seccion4()

main() # Llamado de la funcion
