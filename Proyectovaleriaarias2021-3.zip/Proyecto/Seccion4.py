import Funciones # Importamos funciones 

def seccion4(): #Funcion de seccion 4, estadisticas del programa
  # Archivo de control de guardados 
  comisiones = Funciones.crear_lista('comisiones.txt') 
  if len(comisiones) != 0:
    comisiones.pop(0) 
    lista_comisiones = Funciones.convertir_float(comisiones)
    lista_comisiones = sum(lista_comisiones)
  else:
    lista_comisiones = 0

  companias = Funciones.crear_lista('companias.txt')
  if len(companias) != 0:
    companias.pop(0) 
    lista_companias = Funciones.convertir_float(companias)
    lista_companias =sum(lista_companias)
  else:
    lista_companias = 0 

  exoneradas = Funciones.crear_lista('exoneradas.txt')
  if len(exoneradas) != 0:
    exoneradas.pop(0)
    lista_exoneradas = Funciones.convertir_int(exoneradas)
    lista_exoneradas = sum(lista_exoneradas) 
  else:
    lista_exoneradas = 0

  personas = Funciones.crear_lista('personas.txt')
  if len(personas) != 0:
    personas.pop(0) 
    lista_personas = Funciones.convertir_float(personas)
    lista_personas = sum(lista_personas)
  else:
    lista_personas = 0

  splits = Funciones.crear_lista('splits.txt')
  if len(splits) != 0:
    splits.pop(0) 
    lista_splits = Funciones.convertir_int(splits)
    lista_splits = sum(lista_splits)
  else:
    lista_splits = 0

  tipo_compania = Funciones.crear_lista('tipo compania.txt')
  if len(tipo_compania) != 0:
    tipo_compania.pop(0)
    lista_tipo_c = Funciones.convertir_int(tipo_compania)
    lista_tipo_c = sum(lista_tipo_c)/3
  else:
    lista_tipo_c = 0
 
  tipo_persona = Funciones.crear_lista('tipo persona.txt')
  if len(tipo_persona) != 0:
    tipo_persona.pop(0) 
    lista_tipo_p = Funciones.convertir_int(tipo_persona)
    lista_tipo_p = sum(lista_tipo_p)/3
  else:
    lista_tipo_p = 0

  #Buscar el top de los 3 balances mas altos de Saman Pay en la lista de balances

  top_balances = Funciones.crear_lista('balances.txt') 
  top_balances.pop(0)
  
  if len(top_balances) >= 3 :
    top_balances = sorted(top_balances) #ordenando la lista
    top_1 = top_balances[-1] #asignar valores despues de busqueda
    top_2 = top_balances[-2]
    top_3 = top_balances[-3]
    mejores_balances = [top_1,top_2,top_3] #lista obtenida
  
  elif top_balances != 0:
    top_balances = sorted(top_balances) #ordenando lista
    top_1 = top_balances[-1] #asignar valores despues de busqueda
    mejores_balances = top_1 #lista obtenida
    
  
  #impresion del archivo
  estadisticas = open('Estadisticas Saman Pay.txt','a')
  estadisticas.write(f'<<<\nESTADISTICAS SAMAN PAY>>>\n\nMonto total recaudado por comisiones >>> {lista_comisiones}\nMonto total recaudado por personas >>>> {lista_personas}\nMonto total recaudado por companias >>>> {lista_companias}\nTransferencias exoneradas >>>>{lista_exoneradas}\nCantidad de usuarios persona >>>> {lista_tipo_p}\nCantidad de usuarios compania >>>> {lista_tipo_c}\nCantidad de splits realizados >>>> {lista_splits}\n\nTopde los mejores 3 balances en Saman Pay >>>> {mejores_balances}')
  estadisticas.close()
