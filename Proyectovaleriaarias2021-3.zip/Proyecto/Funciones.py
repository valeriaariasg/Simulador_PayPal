import email.utils  #libreria para validar un correo
import re #libreria para validar un correo
import datetime #libreria para obterner hora y fecha actual
import random #libreria para obtener un codigo de transaccion distinto siempre

def email(correo_usuario): #f uncion para validar los correos
  patron = r'^[a-z][a-z0-9\-_\.]+[@][a-z]+[.][a-z]{1,3}$'
  return re.search(patron, correo_usuario)

def numeros_capicua(monto): # Valida si son numeros capicua
  if monto == monto[::-1]:
    return True # Verificado capicua exitosamente
  else:
    return False # Verificacion fallida, no son numeros de tipo capicua

def fecha(): # Extrae la fecha del sistema para las operaciones
  fecha = datetime.datetime.now()
  fecha_actual = str(fecha.year) +'-'+ '0'+str(fecha.month) +'-'+str (fecha.day) # Completa la fecha a extraer y la pone en formato
  return fecha_actual

def hora(): # Extrae la hora del sistema para las operaciones
  hora = datetime.datetime.now() # Extrae la hora 
  hora_actual = str(hora)[11:16] 
  return hora_actual 

def codigo_random(): # Genera un codigo al azar para las transferencias
  n = random.randint(10000000,90000000)
  return n

def crear_lista(archivo): #pasar los datos contenidos en archivo txt a lista
  archivo_lista = []
  with open(archivo) as a:
    for line in a:
      archivo_lista.append(line.split(',')[0])
  return archivo_lista

def retornar_valores(lista, archivo): #retornar los datos contenidos en una lista a un archivo
  nuevos_valores = open(archivo, 'w')
  for j in range(1,len(lista)):
    valor_nuevo = lista[j]
    nuevos_valores.write(f'\n{valor_nuevo},') # Sobreescritura de informacion
  nuevos_valores.close()

def buscar_indice(lista, valor): #hallar indice de variables repetidas
  valores_repetidos = [i for i, n in enumerate(lista) if n == valor]
  return valores_repetidos
    
def convertir_int(nombre_lista): #convertir valores de una lista str a int
  lista_int = [int(x) for x in nombre_lista]
  return lista_int

def convertir_float(nombre_lista): #convertir valores de una lista str a float
  lista_float = [float(x) for x in nombre_lista]
  return lista_float
